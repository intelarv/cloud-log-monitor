import app from "./app";
import { logger } from "./lib/logger";
import { bootstrap } from "@workspace/db";
import { verifyChain } from "./lib/ledger";
import { startChainVerifier, startNotarizer } from "./lib/chain-verifier";
import { backfillEmbeddings, reconcileSearchIndex } from "./lib/search";
import { initEmbedderFromEnv } from "./lib/embedder-config";
import { initSearchProviderFromEnv } from "./lib/search-config";
import { initRawEvidenceStoreFromEnv } from "./lib/raw-evidence-store";
import { initNerProviderFromEnv } from "./lib/ner-config";
import {
  initEmbeddingsPartitioningFromEnv,
  reconcileEmbeddingsPartitioningFromDb,
} from "./lib/embeddings-partition-config";
import { initLlmRuntimeFromEnv } from "./lib/llm-runtime-config";
import { hasDedicatedNotarizationSecret } from "./lib/notarization";
import { loadTenantKmsCacheFromDb } from "./lib/tenant-kms";
import { startIngestPipeline } from "./lib/ingest";
import { startRawEvidenceTiering } from "./lib/raw-evidence-tiering";
import { startMemoryEviction } from "./lib/memory-eviction";
import { startLogSourceReaper } from "./lib/log-source-reaper";
import { initLogBusFromEnv } from "./lib/log-bus-config";
import { buildLogSourceFromEnv } from "./lib/log-source-config";
import type { LogRecord } from "./lib/log-source";
import { startAgentSupervisor } from "./lib/agents/supervisor";
import { getWorkflowEngine } from "./lib/agents/workflow-engine";
import { buildChannelsFromEnv, initChannels } from "./lib/channels";

const rawPort = process.env["PORT"];
if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}
const port = Number(rawPort);
if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

async function main(): Promise<void> {
  // Step 0: resolve the embedder from env (provider, model, dim) BEFORE
  // bootstrap so the DB column dim matches what the embedder will produce.
  // See embedder-config.ts for precedence (EMBEDDING_PROVIDER > DEPLOYMENT_TARGET).
  const { config: embedderConfig } = initEmbedderFromEnv();

  // Step 0.5: resolve the LLM agent runtime from env. Default is the Replit
  // Gemini integration (dev/local); `aws` / `gcp` / `azure` deployment
  // targets swap in Bedrock Converse / Vertex generateContent / Azure
  // OpenAI Chat Completions respectively. PHI guard wraps every cloud
  // provider. See llm-runtime-config.ts.
  initLlmRuntimeFromEnv();

  // Step 0.7: resolve the lexical (BM25) search provider from env. Default is
  // Postgres FTS (dev/local); SEARCH_PROVIDER=opensearch routes the lexical
  // retriever leg to a managed OpenSearch cluster. No DB access here, so this
  // ordering vs bootstrap is flexible. See search-config.ts.
  initSearchProviderFromEnv();

  // Step 0.8: resolve the raw-evidence store from env. Default is the inline
  // `raw_evidence` jsonb column (dev/local); RAW_EVIDENCE_PROVIDER=s3|gcs|
  // azure-blob retargets unredacted PHI to a WORM object store (Object Lock /
  // retention / immutability). No DEPLOYMENT_TARGET shortcut — moving raw PHI
  // is always explicit (needs a bucket/container). No DB access here. See
  // raw-evidence-store.ts.
  initRawEvidenceStoreFromEnv();

  // Step 0.9: resolve the optional Stage-2 NER provider from env. Default is
  // `none` (NoopNerProvider) so detection runs Stage-1 only and the offline
  // eval gate is byte-identical. NER_PROVIDER=aws-comprehend|gcp-dlp|
  // azure-language augments ingest detection with cloud NER (un-anchored names
  // / free-form addresses) — no DEPLOYMENT_TARGET shortcut, always explicit.
  // No DB access here. See ner-config.ts.
  initNerProviderFromEnv();

  // Step 0.95 (M12.2): resolve the per-tenant pgvector partitioning switch.
  // Default off ⇒ single-table finding_embeddings, byte-identical to pre-M12.2.
  // When EMBEDDINGS_TENANT_PARTITIONING is on, bootstrap recreates the table as
  // LIST-partitioned by tenant_id (DEFAULT partition keeps un-provisioned
  // tenants behaving identically), and the embedding upsert switches its ON
  // CONFLICT arbiter to the composite PK. See embeddings-partition-config.ts.
  const embeddingsPartitioned = initEmbeddingsPartitioningFromEnv();

  // Step 1: idempotent DB setup (RLS policies + findings_redacted view).
  // Safe to run every boot; CREATE OR REPLACE / DROP IF EXISTS make it so.
  // The embedding-column dim is passed through; if a pre-existing column has
  // a different dim, bootstrap throws with a clear migration message.
  logger.info("Running DB bootstrap (setup + seed-if-empty)");
  const boot = await bootstrap({
    embeddingDim: embedderConfig.dim,
    tenantPartitioning: embeddingsPartitioned,
  });
  logger.info(boot, "DB bootstrap complete");

  // Step 1.05 (M12.2): reconcile the runtime partitioning switch with the
  // ACTUAL table layout. bootstrap only converts single→partitioned (never
  // back), so the env flag can drift from the schema; trusting the catalog
  // keeps the embedding upsert's ON CONFLICT arbiter consistent with the table
  // and avoids a runtime arbiter mismatch. No-op when they already agree.
  const actuallyPartitioned = await reconcileEmbeddingsPartitioningFromDb();
  logger.info(
    { embeddingsPartitioned: actuallyPartitioned },
    "finding_embeddings layout reconciled",
  );

  // Step 1.1 (M12.1): load the per-tenant KMS key registry into the in-memory
  // resolver cache, now that bootstrap has ensured the table exists. Default-
  // inert: an empty registry (the dev/eval default) leaves every tenant on the
  // global secret, so cookie signatures stay byte-identical to pre-M12.1.
  const kms = await loadTenantKmsCacheFromDb();
  logger.info({ tenantKeys: kms }, "Per-tenant KMS registry loaded");

  // Step 1.5 (M1): backfill embeddings for any finding without one (or
  // re-embed when the embedder version has changed). Idempotent; cheap when
  // already converged. Uses the embedder registered in step 0.
  const emb = await backfillEmbeddings();
  logger.info(emb, "Embedding backfill complete");

  // Step 1.6 (M10.1): reconcile the external lexical index. No-op for the
  // Postgres provider (generated tsv is always in sync); for OpenSearch it
  // bulk-mirrors every finding's redacted projection so a freshly-pointed
  // cluster converges. Idempotent. Best-effort: an external search backend
  // (OpenSearch) is a separate failure domain — if it is down at boot we must
  // still come up and serve traffic. Hybrid search degrades to the vector leg
  // until the backend recovers, and the next restart reconciles. The Postgres
  // no-op cannot fail here, so this only shields external providers.
  try {
    const recon = await reconcileSearchIndex();
    logger.info(recon, "Search index reconcile complete");
  } catch (err) {
    logger.warn(
      { err },
      "Search index reconcile failed at boot; continuing (hybrid search degrades to vector-only until the backend recovers and the next reconcile runs)",
    );
  }

  // Step 2: chain verification. The system's tamper-evidence claim depends
  // on this; if the chain is broken at boot, we refuse to start.
  // See ARCHITECTURE.md §23.2.
  const v = await verifyChain();
  logger.info(
    {
      ok: v.ok,
      walked: v.walked,
      head_seq: v.head_seq,
      head_hash_short: v.head_hash.slice(0, 16),
    },
    "Ledger chain verification",
  );
  if (!v.ok) {
    logger.error({ errors: v.errors }, "Ledger chain INVALID — refusing to start");
    process.exit(2);
  }

  // Step 3 (M1.8): start the periodic chain verifier — hourly 24h-window
  // walk + weekly full walk. On mismatch it appends `ledger.chain_invalid`
  // whose post-commit alert hook routes via §25. See ARCHITECTURE.md §23.2.
  // M2 notarization checkpoint create+verify is no longer driven here — it now
  // runs through the WorkflowEngine seam (`startNotarizer`, step 5.5) so it can
  // be made durable under WORKFLOW_ENGINE=temporal.
  if (!hasDedicatedNotarizationSecret()) {
    logger.warn(
      "NOTARIZATION_SECRET is not set; falling back to SESSION_SECRET-derived dev key. " +
        "Production deployments MUST set NOTARIZATION_SECRET to a value held in a SEPARATE trust zone " +
        "(separate KMS / separate cloud account) per ARCHITECTURE.md §23.2 — co-locating the two " +
        "secrets defeats the second-half tamper-evidence guarantee.",
    );
  }
  startChainVerifier();

  // Step 4 (M3): wire the ingest pipeline to the process-wide log bus.
  // Source adapters publish `LogRecord`s; the pipeline runs Stage-1
  // detectors and produces findings + ledger entries. The in-memory bus
  // is the dev stand-in for Kafka/Redpanda/NATS per ARCHITECTURE.md §3 —
  // production swaps the bus impl without touching the pipeline.
  // No source is auto-started; POST /api/admin/ingest/replay triggers
  // the static fixture source on demand.
  //
  // The bus impl is env-selected (`LOG_BUS_PROVIDER=memory|kafka|nats`,
  // default in-memory). We init + subscribe the pipeline FIRST, then call
  // `bus.start?.()` so a brokered consume loop sees the registered handler.
  const bus = initLogBusFromEnv();
  startIngestPipeline(bus);
  await bus.start?.();

  // Step 4.7 (tiered storage): start the raw-evidence tiering lifecycle. Ages
  // inline raw PHI out of the hot `findings.raw_evidence` column into the
  // configured external WORM store once a finding is older than
  // RAW_EVIDENCE_TIER_AGE_DAYS, then nulls the inline copy (break-glass still
  // resolves it via raw_evidence_ref). Default-INERT: schedules nothing unless
  // the operator opts in (RAW_EVIDENCE_TIER_AGE_DAYS) AND an external store is
  // configured. With the inline DB store (dev default) there is no WORM tier to
  // age into, so dev boot + the offline eval gate are byte-identical. The store
  // was resolved in step 0.8. See raw-evidence-tiering.ts.
  startRawEvidenceTiering();

  // Step 4.8 (memory eviction): start the importance-decay eviction + group-
  // consolidation lifecycle over the `finding_embeddings` derived cache. Bounds
  // the vector memory per tenant (top-N by a deterministic importance score)
  // and collapses old/resolved duplicates, while NEVER evicting a critical+open
  // finding. Prunes only the derived embedding cache — never the findings audit
  // record, and the lexical/BM25 retrieval leg still finds evicted findings.
  // Default-INERT: schedules nothing unless the operator opts in
  // (MEMORY_MAX_EMBEDDINGS_PER_TENANT). With it unset, dev boot + the offline
  // eval gate are byte-identical, and the boot backfill above is unchanged. The
  // backfill shares the same eligibility oracle so it never recreates what
  // eviction removed. See memory-eviction.ts.
  startMemoryEviction();

  // Step 4.9 (M8 reaper): start the stuck-cursor reaper. Periodically scans
  // `log_source_checkpoints` for poller cursors that have stopped advancing past
  // the operator-configured stall threshold and emits a warning-level
  // `ingest.source_stalled` ledger event so on-call learns a log source went
  // quiet (a potential missed-PHI gap that is otherwise invisible at the finding
  // level). Default-INERT: schedules nothing unless the operator opts in
  // (INGEST_SOURCE_STALL_AFTER_MS). With it unset — and with no cloud source
  // configured the checkpoint table is empty anyway — dev boot + the offline
  // eval gate are byte-identical. Edge-triggered + leader-locked. See
  // log-source-reaper.ts.
  startLogSourceReaper();

  // Step 4.5 (M8): real cloud log source, env-driven. Inert by default — an
  // operator opts in with `LOG_SOURCE=cloudwatch|cloud_logging|azure_monitor`
  // + that provider's required vars (see docs/CONFIGURATION.md). When unset,
  // `buildLogSourceFromEnv` returns null and we keep dev behavior: only the
  // fixture replay endpoint produces records. Same lazy-load pattern as
  // cloud-embedders — each provider SDK is an optional dep that's only
  // required when its branch fires.
  const cloudLogSource = buildLogSourceFromEnv((record: LogRecord) =>
    bus.publish("raw.logs", record),
  );
  if (cloudLogSource) {
    await cloudLogSource.start();
    logger.info({ source: cloudLogSource.name }, "cloud log source started");
  } else {
    logger.info("no cloud log source configured (LOG_SOURCE unset)");
  }

  // Step 5 (M5): start the multi-agent supervisor. Wires the in-memory
  // review queue and arms `maybeEnqueueReviewFromLedger` (already attached
  // to appendLedger's post-commit hook in lib/ledger.ts). On every newly
  // created finding the supervisor runs Triage → Verifier and persists
  // verdicts; both steps ledger with full agent identity per
  // ARCH §7 / §24. Cost is bounded by AGENT_DAILY_TOKEN_BUDGET; concurrency
  // is bounded inside the supervisor module.
  startAgentSupervisor();

  // Step 5.5 (M2 notarizer through the WorkflowEngine seam): schedule the
  // checkpoint create+verify cycle on the active workflow engine. In-process
  // this is a leader-locked 5min setInterval, byte-identical to the pre-seam
  // chain-verifier checkpoint timer it replaces. Under WORKFLOW_ENGINE=temporal
  // it becomes a durable cron workflow (`notarizationWorkflow`) with the same
  // single-execution + crash-resume guarantees as the review path. Wired AFTER
  // startAgentSupervisor so the engine is selected (and, for temporal, started
  // — schedulePeriodic buffers until the worker is up).
  startNotarizer(getWorkflowEngine());

  // Step 6 (M6): wire notification channels (Slack incoming-webhook +
  // generic HMAC-signed webhook). Adapter env is read here and validated
  // by `buildChannelsFromEnv`; inert by default (dev/demo runs with no
  // configured channels — alerts still go to structured stderr and the
  // ledger). The post-commit hook in lib/ledger.ts is already wired to
  // `dispatchAlertFromLedger`; `initChannels` only populates the
  // adapter list it dispatches into. Threat_model §"Application ↔
  // Channel Adapters" trust boundary + §Information Disclosure
  // "Notification PHI guard" hard gate live inside the channels module.
  initChannels(buildChannelsFromEnv());

  app.listen(port, (err) => {
    if (err) {
      logger.error({ err }, "Error listening on port");
      process.exit(1);
    }
    logger.info({ port }, "Server listening");
  });
}

main().catch((err) => {
  logger.error({ err }, "Fatal startup error");
  process.exit(1);
});
